<form action="submit.php" method="POST">
    <input type="text" name="name" placeholder="Full Name" required><br>
    <input type="tel" name="phone" placeholder="Phone Number" required><br>
    <input type="email" name="email" placeholder="Email Address" required><br>
    <textarea name="message" placeholder="Your Message" required></textarea><br>
    <button type="submit"><i class="fab fa-telegram-plane"></i> Submit</button>
</form>
<style>
    form {
    max-width: 400px;
    margin: 30px auto;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

form input[type="text"],
form input[type="tel"],
form input[type="email"],
form textarea {
    width: 100%;
    padding: 12px 15px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 15px;
    transition: border-color 0.3s ease;
}

form input:focus,
form textarea:focus {
    border-color: #007bff;
    outline: none;
}

form textarea {
    resize: vertical;
    min-height: 100px;
}

form button {
    width: 100%;
    padding: 12px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

form button:hover {
    background-color: #0056b3;
}

form button i {
    margin-left: 8px;
}

</style>